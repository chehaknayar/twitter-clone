<?php
use Illuminate\Database\Seeder;
class UserTableSeeder extends Seeder
{

public function run()
{
    DB::table('users')->delete();
    App\User::create(array(
        'firstname'     => 'Chris ',
        'lastname'     => 'Sevilleja',
        'email'    => 'chris@scotch.io',
        'password' => Hash::make('awesome'),
        'status' => '#loving my life so much',
    ));
}

}
