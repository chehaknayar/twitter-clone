<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




Route::group(['middleware' => 'guest'], function (){

	
	Route::get('login', 'AuthController@signin')->name('auth.signin');
	Route::post('login', 'AuthController@signInUser')->name('auth.signinUser');
	Route::get('signup', 'AuthController@userSignUp')->name('auth.userSignUp');
	Route::post('signup', 'AuthController@signUpUser')->name('auth.signUpUser');
});

Route::group(['middleware' => 'auth'], function (){
	
	Route::get('', 'MainController@main')->name('auth.main');
	Route::get('users/{slug}', 'UsersController@show')->name('users.show');
	Route::get('users/{slug}/toggleFollow', 'UsersController@toggleFollow')->name('users.toggleFollow');
	
	Route::get('tweets','TweetsController@post')->name('auth.tweets');
	Route::post('tweets','TweetsController@tweetsmthn')->name('auth.tweetsmthn'); 
	
	Route::get('logout', 'AuthController@logoutUser')->name('auth.logOutUser');
});
