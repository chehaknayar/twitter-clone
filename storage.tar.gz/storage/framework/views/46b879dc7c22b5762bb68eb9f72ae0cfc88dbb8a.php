<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />	
	<title>Sign In Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<!-- stylesheets -->
	<link rel="stylesheet" type="text/css" href="tweet/public/css/compiled/theme.css">

	<!-- javascript -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="/js/bootstrap.min.js"></script>
	<script src="/js/theme.js"></script>

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body id="signup" link="blue"
	<div class="container">
		<div class="row header">
			<div class="text">
				<h3 class="logo">
					<img src="tweet/resources/views/twitter.png" alt="globe" height="42" width="42" />
					<a href="signin.html"><b><sub>witter</sub></b></a>
				</h3>
				<h4>Log in to your twitter account.</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="wrapper clearfix">
					<div class="formy">
						<div class="row">
							<div class="col-md-12">
								<form role="form">
							  		<div class="form-group">
							    		<label for="email">Email address</label>
							    		<input type="email" class="form-control" id="email" placeholder="Phone,email or username" required autofocus />
							  		</div>
							  		<div class="form-group">
							    		<label for="password">Password</label>
							    		<input type="password" class="form-control" id="password" placeholder="Password" required />
							  		</div>
							  		<div class="checkbox">
							    		<label>
							      			<input type="checkbox"> Remember me
							    		</label>
							  		</div>
							  		<div class="submit">
							  			<a href="signin.html" class="button">
								  			<span>Log in</span>
								  		</a>
							  		</div>
								</form>
							</div>
						</div>						
					</div>
				</div>
				<div class="already-account">
					New to twitter?
					<a href="signup.html" class="button">Sign up now</a>
				</div>
					<div class="message">
						Already using twitter via text message
						<a href="signup.html" class="button">activate your account</a>
					</div>
			</div>
		</div>
	</div>
</body>
</html>