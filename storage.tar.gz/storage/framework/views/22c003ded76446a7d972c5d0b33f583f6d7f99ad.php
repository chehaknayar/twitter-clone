<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />	
	<title>Twitter</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<!-- stylesheets -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/theme.css")); ?>>

	<!-- javascript -->
	<script src=<?php echo e(asset("js/jquery.min.js")); ?>></script>
	<script src=<?php echo e(asset("js/bootstrap.min.js")); ?>></script>
	<script src=<?php echo e(asset("js/theme.js")); ?>></script>

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body id="signup">
	<div class="container">
		<div class="row header">
			<div class="col-md-12">
				<h3 class="logo">
					<a href="index.html">Twitter</a>
				</h3>
				<h4>Set up your new account today.</h4>
				
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="wrapper clearfix">
					<div class="formy">
						<div class="row">
							<div class="col-md-12">
								<form action="<?php echo e(route('auth.signUpUser')); ?>" method="POST" role="form">
							  		<?php echo e(csrf_field()); ?>

									<form role="form">
										<div class="form-group">
							    			<label for="name">Your name</label>
							    			<input type="text" name="name"class="form-control" id="name" />
							    			<?php echo e($errors->first('name')); ?>

							 	 		</div>
							 	 		<div class="form-group">
							 		   		<label for="email">Email address</label>
							    			<input type="email" name="email" class="form-control" id="email" />
							    			<?php echo e($errors->first('email')); ?>

							  			</div>
							  			<div class="form-group">
							    			<label for="password">Password</label>
							    			<input type="password" name="password" class="form-control" id="password" />
							    			<?php echo e($errors->first('password')); ?>

							  			</div>
							  			<div class="checkbox">
							    			<label>
							    	  			<input type="checkbox"> Agree to the 
							    	  			<a href="#">Terms of service</a>.
							    			</label>
							  			</div>
							  			<div class="submit">
							  				<button class="button" type="submit">
									  			Create my account
									  		</button>
							  			</div>
									</form>
							</div>
						</div>						
					</div>
				</div>
				<div class="already-account">
					Already have an account?
					<a href="login" class="button">LogIn</a>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		$(function () {
			$(".already-account a").popover();
			$(".already-account a").popover('show');
		});
	</script>
</body>
</html>