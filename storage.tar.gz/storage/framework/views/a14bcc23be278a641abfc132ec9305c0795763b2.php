<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />	
	<title>2.Twitter clone main page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<!-- stylesheets -->
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/theme.css")); ?>>
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/font-awesome.css")); ?>>
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/icomoon.css")); ?>>

	<!-- javascript -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src=<?php echo e(asset("js/bootstrap.min.js")); ?>></script>
	<script src=<?php echo e(asset("js/theme.js")); ?>></script>

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body id="blog">
	<header class="navbar navbar-inverse normal" role="banner">
  		<div class="container">
    		<div class="navbar-header">
		      	<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
		      	</button>
      			<a href="index.html" class="navbar-brand">Twitter</a>
    		</div>
    		<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
      			<ul class="nav navbar-nav">
      				<li class="dropdown">
        				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
          					Home <b class="caret"></b>
          				</a>
          				<ul class="dropdown-menu">
							<li><a href="index.html">Home 1 (Static)</a></li>
							<li><a href="index3.html">Home 2 (Sidebar menu)</a></li>
							<li><a href="index4.html">Home 3 (Slider)</a></li>
				        </ul>
        			</li>
      				
        			<li class="dropdown">
        				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
          					More pages <b class="caret"></b>
          				</a>
          				<ul class="dropdown-menu">
							<li><a href="aboutus.html">About us</a></li>
							<li><a href="contactus.html">Contact us</a></li>
							<li><a href="gallery.html">Gallery</a></li>
							<li><a href="portfolio.html">Portfolio</a></li>
							<li><a href="portfolio-item.html">Portfolio Item</a></li>
							<li><a href="invoice.html">Invoice page</a></li>
							<li><a href="timeline.html">Timeline Page</a></li>
							<li><a href="docs.html">API Documentation</a></li>
							<li><a href="support.html">Support</a></li>
							<li><a href="coming-soon.html">Coming Soon</a></li>
							<li><a href="status.html">Status</a></li>
							<li><a href="signup.html">Sign Up & Sign In</a></li>
							<li><a href="signup-rotate.html">Sign Up Miscellaneous</a></li>
							<li><a href="404.html">404 Page</a></li>
				        </ul>
        			</li>
        			<li class="active dropdown">
        				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
	      					Top tweets <b class="caret"></b>
	      				</a>
	      				<ul class="dropdown-menu">
							<li><a href="blog.html">Blog </a></li>
							<li><a href="blogpost.html">Blog post</a></li>
				        </ul>
        			</li>
      			</ul>
      			<ul class="nav navbar-nav navbar-right visible-md visible-lg">
      				<li>
          				<a href="signup.html" class="button">Sign up free</a>
        			</li>
      			</ul>
    		</nav>
  		</div>
	</header>

	<div id="posts">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="post">
						<a href="blogpost.html" class="pic">
							
						</a>

						<div class="title">
							<a href="blogpost.html">James Smith</a>
						</div>
						<div class="author">
							<img src=<?php echo e(asset("images/testimonials/testimonial2.jpg" )); ?>class="avatar" alt="author" />
							10.00am, October 03, 2013
						</div>
						<p class="intro">
							<i>"By Ed Hawkins, University of Reading. Climate change is often seen as a recent phenomenon, but its roots are actually far older — the stuff that is currently happening is beyond my understanding.</i>
							<br />
							<i>Some people say design is about solving problems. Obviously designers solve problems but so do dentists. Design is about cultural invention."</i>
						</p>
						
					</div>

					<div class="post">
						<div class="video">
							
						</div>

						<div class="title">
							<a href="blogpost.html">Eric Hoffman</a>
						</div>
						<div class="author">
							<img src=<?php echo e(asset("images/testimonials/testimonial1.jpg")); ?> class="avatar" alt="author" />
							 9.38am, October 11, 2013
						</div>
						<p class="intro">
							<i>By Ed Hawkins, University of Reading. Climate change is often seen as a recent phenomenon, but its roots are actually far older — the stuff that is currently happening is beyond my understanding.</i>
							<br />
							<i>Some people say design is about solving problems. Obviously designers solve problems but so do dentists. Design is about cultural invention."</i>
						</p>
						
					</div>

					<div class="post">
						<a href="blogpost.html" class="pic">
							
						</a>

						<div class="title">
							<a href="blogpost.html">Amanda Johnson</a>
						</div>
						<div class="author">
							<img src=<?php echo e(asset("images/testimonials/testimonial4.jpg")); ?> class="avatar" alt="author" />
							8.57am, September 23, 2013
						</div>
						<p class="intro">
							<i>By Ed Hawkins, University of Reading. Climate change is often seen as a recent phenomenon, but its roots are actually far older — the stuff that is currently happening is beyond my understanding."</i>
						</p>
						
					</div>

					<div class="post">
						<a href="blogpost.html" class="pic">
							
						</a>

						<div class="title">
							<a href="blogpost.html">Benjamin Andrews</a>
						</div>
						<div class="author">
							<img src=<?php echo e(asset("images/testimonials/testimonial3.jpg")); ?> class="avatar" alt="author" />
							6.30pm, August 16, 2013
						</div>
						<p class="intro">
							<i>By Ed Hawkins, University of Reading. Climate change is often seen as a recent phenomenon, but its roots are actually far older — the stuff that is currently happening is beyond my understanding.</i>
							<br />
							<i>Some people say design is about solving problems. Obviously designers solve problems but so do dentists. Design is about cultural invention."</i>
						</p>
						
					</div>

					<div class="pages">
						<ul class="pagination">
						  	<li><a href="#">&laquo;</a></li>
						  	<li class="active"><a href="#">1</a></li>
						  	<li><a href="#">2</a></li>
						  	<li><a href="#">3</a></li>
						  	<li><a href="#">4</a></li>
						  	<li><a href="#">&raquo;</a></li>
						</ul>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	

	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-3 copyright">
					Twitter © 2014
				</div>
				<div class="col-sm-6 menu">
					<ul>
	      				<li>
	          				<a href="features.html">Home</a>
	        			</li>
	        			<li>
	        				<a href="services.html">Services</a>
	        			</li>
	        			<li>
	          				<a href="pricing.html">Pricing</a>
	        			</li>
	        			<li>
	          				<a href="support.html">Support</a>
	        			</li>
	        			<li class="active">
	          				<a href="blog.html">Blog</a>
	        			</li>
	      			</ul>
				</div>
				<div class="col-sm-3 social">
					<a href="#">
						<img src=<?php echo e(asset("images/social/social-tw.png")); ?> alt="twitter" />
					</a>
					<a href="#">
						<img src=<?php echo e(asset("images/social/social-dbl.png")); ?> alt="dribbble" />
					</a>					
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		$(function () {
			$(".search input:text").focus(function () {
				$(".icomoon-search").addClass("active");
			});
			$(".search input:text").blur(function () {
				$(".icomoon-search").removeClass("active");
			});
		});
	</script>
</body>
</html>