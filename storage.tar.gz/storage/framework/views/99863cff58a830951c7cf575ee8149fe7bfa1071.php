<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />	
	<title>Sign In Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<!-- stylesheets -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/theme.css")); ?>>

	<!-- javascript -->
	<script src=<?php echo e(asset("js/jquery.min.js")); ?>></script>
	<script src=<?php echo e(asset("js/bootstrap.min.js")); ?>></script>
	<script src=<?php echo e(asset("js/theme.js")); ?>></script>

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body id="signup" link="blue"
	<div class="container">
		<div class="row header">
			<div class="text">
				<h3 class="logo">
					<img src=<?php echo e(asset('images/twitter.png')); ?> alt="globe" height="42" width="42" />
					

					<a><b>witter</b></a>
				</h3>
				<h4>Log in to your twitter account.</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="wrapper clearfix">
					<div class="formy">
						<div class="row">
							<div class="col-md-12">
								<?php if(session()->has('error_message')): ?>
									<?php echo e(session()->get('error_message')); ?>

								<?php endif; ?>
								<form action="<?php echo e(route('auth.signinUser')); ?>" method="POST" role="form">
							  		<?php echo e(csrf_field()); ?>

							  		<div class="form-group">
							    		<label for="email">Email address</label>
							    		<input type="email" name="email" class="form-control" id="email" placeholder="Phone,email or username" required autofocus />
							  		</div>
							  		<div class="form-group">
							    		<label for="password">Password</label>
							    		<input type="password" name="password" class="form-control" id="password" placeholder="Password" required />
							  		</div>
							  		<div class="checkbox">
							    		<label>
							      			<input type="checkbox"> Remember me
							    		</label>
							  		</div>
							  		
							  		<div class="submit">
							  			<button class="button" type="submit">
								  			Login
								  		</button>
							  		</div>
								</form>
							</div>
						</div>						
					</div>
				</div>
				<div class="already-account">
					New to twitter?
					<a href="signup" class="button">Sign up now</a>
				
			</div>
		</div>
	</div>
</body>
</html>