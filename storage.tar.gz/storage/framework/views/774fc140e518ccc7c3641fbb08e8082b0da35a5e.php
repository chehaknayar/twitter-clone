<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />	
	<title>2.Twitter clone main page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<!-- stylesheets -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/theme.css")); ?>>
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/font-awesome.css")); ?>>
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/icomoon.css")); ?>>
	<link rel="stylesheet" type="text/css" href=<?php echo e(asset("css/styles.css")); ?>>

	<!-- javascript -->
	<script src=<?php echo e(asset("js/jquery.min.js")); ?>></script>
	<script src=<?php echo e(asset("js/bootstrap.min.js")); ?>></script>
	<script src=<?php echo e(asset("js/theme.js")); ?>></script>

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body id="blog">
	<header class="navbar navbar-inverse normal" role="banner">
  		<div class="container">
    		<div class="navbar-header">
		      	<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
		      	</button>
      			<a  class="navbar-brand">Twitter</a>
    		</div>
    		<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
      			<ul class="nav navbar-nav">
      				
      				
        			
        			<li class="active dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            Tweets <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                           
                            <li><a href="/">NewsFeed</a></li>
                        </ul>
                    </li>
      			</ul>
      			<ul class="nav navbar-nav navbar-right visible-md visible-lg">
                    <li>
                    <?php if(auth()->check()): ?> 
                        <a href="<?php echo e(route('auth.logOutUser')); ?>" class="button">Log out </a>
                    <?php else: ?>
                    
                        <a href="signup" class="button">Sign up free</a>

                    <?php endif; ?>
                    </li>
                </ul>
                 <ul class="nav navbar-nav navbar-right visible-md visible-lg">
                    <li>
                    <?php if(Auth::check()): ?> 
                        
                    <?php else: ?>
                        <a href="login" class="button" style="position:absolute;top:5px;absolute;right:40px" >LogIn</a>
                        
                    <?php endif; ?>
                    </li>
                </ul>
    		</nav>
  		</div>
	</header>

	<div id="posts">
		<div class="container">
			<div class="col-md-12 sidebar">
				<div class="search">
					<form action="<?php echo e(route('auth.tweetsmthn')); ?>" method="POST" role="form">
							  		<?php echo e(csrf_field()); ?>

					
							
						<input type="text" name="tweet" placeholder="Tweet something" />
						<?php echo e($errors->first('tweet')); ?>

					<button class="button" type="submit" >
						Post
					</button>
					</form>

	</div>
				</div>
				<b><p  class="navbar-brand">My Tweets</p>	</b>
			</div>
		</div>

	
	<div class="row">

	<?php if($tweets->count() > 0): ?>
		<ul>
		<?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

		<p>	<strong><?php echo e($tweet->created_at->format("jS M, Y h:i A")); ?></strong>
		: 
		<font face="goudy stout" color="blue"><i><?php echo e($tweet->content); ?></i></font>
		</p>
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	<?php else: ?>
		<a class="navbar-brand">No tweets to show</a>
	<?php endif; ?>
	</div>
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-3 copyright">
					Twitter © 2017
				</div>
				
				<div class="col-sm-3 social">
					<a href="#">
						<img src=<?php echo e(asset("images/social-tw.png")); ?> alt="twitter" />
					</a>
					<a href="#">
						<img src=<?php echo e(asset("images/social-dbl.png")); ?> alt="dribbble" />
					</a>					
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
		$(function () {
			$(".search input:text").focus(function () {
				$(".icomoon-search").addClass("active");
			});
			$(".search input:text").blur(function () {
				$(".icomoon-search").removeClass("active");
			});
		});
	</script>
</body>
</html>