<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" /> 
    <title>2.Twitter clone main page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- stylesheets -->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href={{ asset("css/theme.css") }}>
    <link rel="stylesheet" type="text/css" href={{ asset("css/font-awesome.css") }}>
    <link rel="stylesheet" type="text/css" href={{ asset("css/icomoon.css") }}>

    <!-- javascript -->
    <script src={{ asset("js/jquery.min.js") }}></script>
    <script src={{ asset("js/bootstrap.min.js") }}></script>
    <script src={{ asset("js/theme.js") }}></script>

    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body id="blog">
    <header class="navbar navbar-inverse normal" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">Twitter</a>
            </div>
            <nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
                <ul class="nav navbar-nav">
                <li class="active dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            Tweets <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="tweets">My Tweets </a></li>
                            
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right visible-md visible-lg"></ul>
                    <li>
                    @if(Auth::check()) 
                        <a href="{{ route('auth.logOutUser') }}" class="button" style="position:absolute;top:20px;absolute;right:20px" >LogOut </a>
                    @else
                        <a href="signup" class="button">Sign up free</a>

                    @endif
                    </li>
                
                <ul class="nav navbar-nav navbar-right visible-md visible-lg">
                    <li>
                    @if(Auth::check()) 
                        
                    @else
                        <a href="login" class="button" style="position:absolute;top:5px;absolute;right:40px" >LogIn</a>
                        
                    @endif
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div id="posts">

        <div class="container">
        <b><p class="navbar-brand">NewsFeed</p></b>   
            <div class="row">
                <div class="col-md-12">

                    <div class="post">
                        <a  class="pic">
                         
                        </a>

                        @if($tweets->count() > 0))
                            @foreach($tweets as $tweet)
                            <div class="title">
                                <a href="{{ route('users.show',[$tweet->user->slug]) }}">{{$tweet->user->name}}</a>
                            </div>
                            <div class="author">
                                <p> <strong>{{ $tweet->created_at->format("jS M, Y h:i A") }}</strong>
                                </p>
                            </div>
                            <p class="intro">
                                <i>{{$tweet->content}}</i>
                                
                            
                            </p>
                            @endforeach
                        @else
                         
                            <a class="navbar-brand">No tweets to show</a>
                            
                        @endif
                    </div>

                    

                    <div class="pages">
                        <ul class="pagination">
                            <li><a href="#">&laquo;</a></li>
                            <li class="active"><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">&raquo;</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    

    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 copyright">
                    Twitter © 2014
                </div>
                <div class="col-sm-6 menu">
                    
                </div>
                <div class="col-sm-3 social">
                    <a >
                        <img src={{ asset("images/social-tw.png")}} alt="twitter" />
                    </a>
                    <a >
                        <img src={{ asset("images/social-dbl.png")}} alt="dribbble" />
                    </a>                    
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(function () {
            $(".search input:text").focus(function () {
                $(".icomoon-search").addClass("active");
            });
            $(".search input:text").blur(function () {
                $(".icomoon-search").removeClass("active");
            });
        });
    </script>
</body>
</html>