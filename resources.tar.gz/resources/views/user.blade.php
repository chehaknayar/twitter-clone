<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />	
	<title>Account profile</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<!-- stylesheets -->
	<link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}">
	<link rel="stylesheet" type="text/css" href={{ asset("css/theme.css")}}>
	<link rel="stylesheet" type="text/css" href={{ asset("css/animate.css")}}>

	<!-- javascript -->
	<script src={{ asset("js/jquery.min.js")}}></script>
	<script src={{ asset("js/bootstrap.min.js")}}></script>
	<script src={{ asset("js/theme.js")}}></script>

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
  
</head>
<body id="home4">
	<header class="navbar navbar-inverse hero" role="banner">
  		<div class="container">
    		<div class="navbar-header">
		      	<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
		      	</button>
      			<a  class="navbar-brand">Twitter</a>
    		</div>
    		<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
      			<ul class="nav navbar-nav navbar-right">
      				<li class="dropdown">
        				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
          					Home<b class="caret"></b>
          				</a>
          				<ul class="dropdown-menu">
							<li><a href="/">main (Current)</a></li>
							
				        </ul>
        			</li>
        			
        			
        			
        			<li class="dropdown">
        				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
          					Tweets <b class="caret"></b>
          				</a>
          				<ul class="dropdown-menu">
							<li><a href="{{ route('auth.tweets') }}">My Tweets</a></li>
							
				        </ul>
        			</li>

<li>
        				@if(auth()->check())) 
		                    <a href="{{ route('auth.logOutUser') }}" class="button" style="position:absolute;top:-90px;absolute;right:30px" >LogOut</a>
		                @else
		                    
		                    <a href="signup" class="button">Sign up free</a>

		                @endif
		                </li>
      			</ul>
    		</nav>
  		</div>
	</header>
		
	<div id="hero">
		<ul class="nav navbar-nav navbar-right visible-md visible-lg">
            
        </ul>
        <ul class="nav navbar-nav navbar-right visible-md visible-lg">
            <li>
                @if(Auth::check()) 
                       
                @else
                    <a href="login" class="button" style="position:absolute;top:5px;absolute;right:40px" >LogIn</a>
                        
                @endif
            </li>
        </ul>
		<div class="col-md-6 image">
			<img src={{ asset("images/profle.png")}} class="img-responsive" style="position: static;top: 500px;" alt="pic3" height=300px width=300px />
			<div class="container">
				<p>	<strong><font size=10 color="white">{{ $user->name }}</font></strong>
		</p>
				<div class="cta">
					<a href="{{route('users.toggleFollow',[$user->slug])}}" class="button" style="position:absolute;left:75px">

					{{ ($isFollowing) ? "Unfollow" : "Follow" }}

					</a>
					
				</div>

			
			</div>
		</div>
	</div>
	<frameset cols="10%,65%,25%">
   		<frame name="left" src="/html/top_frame.htm" />
   		<frame name="center" src="/html/main_frame.htm" />
   		<frame name="right" src="/html/bottom_frame.htm" />
   		<noframes>
   			<body>
   				Your browser does not support frames.
   			</body>
   		</noframes>
	</frameset>
	<div id="tabs">
		<div class="container">
			
			<div class="row">
				<div class="col-md-12 tabs-wrapper">
					<ul class="nav nav-tabs">
					  	<li class="active"><a href="#home" data-toggle="tab">Profile Details</a></li>
					  	<li><a href="#profile" data-toggle="tab">Tweets</a></li>
					  	
					  	
					</ul>
					

					<div class="tab-content">
					  	<div class="tab-pane fade in active" id="home">
					  		
					  		<div class="col-md-6 info">
					  			
					  			<p>	<strong><font size=3 color="black">Name:-<font size=3 color="blue">{{ $user->name }}</font></font></strong></p>
					  			<p>	<strong><font size=3 color="black">Email:-<font size=3 color="blue">{{ $user->email }}</font></font></strong></p>
					  			<p>	<strong><font size=3 color="black">Member since:-<font size=3 color="blue">{{ $user->created_at->format("jS M, Y h:i A") }}</font></font></strong></p>
					  		</div>
					  		
					  	</div>
					  	<div class="tab-pane fade" id="profile">
					  		<div class="col-md-6 image">
					  			
					  		</div>
					  		<div class="col-md-12 info">
					  			<h4>@if($tweets)
							<div class="row">
								<ul>
									@foreach($tweets as $tweet) 

									<p>	<strong>{{ $tweet->created_at->format("jS M, Y h:i A") }}</strong>
										: 
									<font face="goudy stout" color="blue"><i>{{ $tweet->content }}</i></font>
									</p>
			
									@endforeach
								</ul></div>
	
							@endif</h4>
					  			
					  		</div>					  		
					  	</div>
					  	
					  	<div class="tab-pane fade" id="settings">
					  		<div class="col-md-6 image">
					  			</div>
					  		<div class="col-md-6 info">
					  			
					  			
					  		</div>
					  	</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	
</body>
</html>