<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
	protected $fillable = [
		'name',
		'email',
		'slug',
	];
	
	public function tweets(){
		return $this->hasMany(Tweet::class)->orderBy('created_at','desc');
	}

	

	public function following(){
		return $this->belongsToMany(User::class,'followers', 'userid','followerid');
	}

	public function followers(){
		return $this->belongsToMany(User::class,'followers', 'followerid','user_id');
	}
}
