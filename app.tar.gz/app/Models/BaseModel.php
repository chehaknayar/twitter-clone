<?php

namespace App\Models;

use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Database\Eloquent\Model;

class BaseModel extends Model
{
	use ValidatesRequests;
}