<?php

namespace App\Models;

class Tweet extends BaseModel {	
	protected $fillable = [
		'content',
	];

	public function user(){
		return $this->belongsTo(User::class, 'user_id');
	}
	
}