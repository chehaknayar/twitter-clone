<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Auth;

class SignupController extends Controller
{
    public function userSignUp(){
    	return view('signup');
    }

    public function signUpUser(Request $request)
	{
		$inputs = request()->except('_token');

		$this->validate($request, [
			'email' => 'required|email|unique:users,email',
			'name' => 'required',
			'password' => 'required',
		]);

		$password = array_get($inputs, 'password');

		$user = User::create($inputs);

		$user->password = bcrypt($password);

		$user->save();

		

		Auth::login($user, true);

		return redirect()->route('auth.main');
	}
}
