<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;

class AuthController extends Controller
{
    public function signin(){
    	return view('login');
	}

	
	public function signInUser(Request $request)
    {

    	$inputs = request()->except('_token');

		$this->validate($request, [
			'email' => 'required|email',
			'password' => 'required',
		]);

		$password = array_get($inputs, 'password');

		$email = array_get($inputs, 'email');
		

        if (Auth::attempt(['email' => $email, 'password' => $password])) {
            // Authentication passed...
            return redirect()->intended('/');
        }

        $request->session()->flash('error_message', "Invalid Credentials!");

        return redirect()->route('auth.signin');
    }

	public function logOutUser()
	{
		Auth::logout();
		return view('login');
	}

    public function userSignUp(){
    	return view('signup');
    }

    public function signUpUser(Request $request)
	{
		$inputs = request()->except('_token');

		$this->validate($request, [
			'email' => 'required|email|unique:users,email',
			'name' => 'required',
			'password' => 'required',
		]);

		$inputs['slug'] = str_slug($inputs['name'] . '-' . time());

		$user = User::create($inputs);

		$password = array_get($inputs, 'password');

		$user->password = bcrypt($password);

		$user->save();
		
		Auth::login($user, true);

		return redirect()->route('auth.main');
	}
}