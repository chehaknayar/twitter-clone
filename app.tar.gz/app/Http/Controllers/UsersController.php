<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UsersController extends Controller
{
    public function show($slug){
    	$user = User::where('slug', '=', $slug)->first();

    	if(! $user) {
    		abort(404);
    	}
    	
    	$logged_in_user = auth()->user();

    	$isFollowing = $logged_in_user->following()->where('users.id', $user->id)->exists();

    	$tweets = $user->tweets;

    	return view('user', compact('user', 'isFollowing', 'tweets')); 
	}

	public function toggleFollow($slug,Request $request){

		$user = User::where('slug', '=', $slug)->first();
		if(! $user) {
    		abort(404);
    	}
		$logged_in_user = auth()->user();

		if($user->id == $logged_in_user->id){
			$request->session()->flash('error_message', "Invalid Credentials!");
			return redirect()->route('users.show', [$user->slug]);
		}


		$isFollowing = $logged_in_user->following()->where('users.id', $user->id)->exists();

		if($isFollowing)
    		$logged_in_user->following()->detach([$user->id]);
    	else
    		$logged_in_user->following()->attach([$user->id]);

    	return redirect()->route('users.show', [$user->slug]);



	}
}
