<?php
namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Auth;
use App\Models\User;

class tweetsController extends Controller
{
    public function post(){
    	$user = auth()->user();

    	$tweets = $user->tweets;

    	return view('tweet', compact('tweets'));
    }
    public function tweetsmthn(Request $request){

    	$this->validate($request, [
			'tweet' => 'required',
		]);

		$tweet = array_get(request()->all(), 'tweet');

		$user = auth()->user();

		$tweet = $user->tweets()->create([
			'content' => $tweet
		]);

		return redirect()->route('auth.tweets');
    }

}
