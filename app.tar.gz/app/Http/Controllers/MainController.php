<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tweet;

class mainController extends Controller
{
    public function main(){
    	$logged_in_user = auth()->user();

    	$tweets = Tweet::whereIn('user_id', $logged_in_user->following->pluck('id')->all())
    		->orderBy('created_at', 'desc')
    		->get();

    	return view('welcome', compact('tweets'));
	}
}
